import { Component ,Input} from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root',
	template: `
	<input type="text" [(ngModel)]="value" />
	<ul>
	<li *ngFor="let point of (points | filterData: value)">
	{{point}}
	</li>
	</ul>
	    `
})

export class AppComponent {
	value:any='';
	points: string[] = [
		 'aa',
		 'bb',
		 'cc',
		 'dd',
		 'ee'
	];
}