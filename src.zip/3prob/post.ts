export class Post {
    constructor(
      public id: number,
      public email: string,
      public name: string,
      public gender: string,
      public status : string
    ) {}
  }