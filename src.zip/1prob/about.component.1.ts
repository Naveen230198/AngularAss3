import { Component } from '@angular/core';

@Component({
  selector: 'app-security',
  template: `<h2>SECURITY</h2>`
})
export class AboutComponent1 { }