import { Component } from '@angular/core';

@Component({
    selector: 'app-home',
    template: `<h2>HOME</h2>`
  })
  export class HomeComponent { }