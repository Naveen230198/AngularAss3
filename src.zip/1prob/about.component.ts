import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `<h2>About</h2>`
})
export class AboutComponent { }