import { Component } from '@angular/core';

@Component({
    selector: 'app-contactUs',
    template: `<h2>CONTACT US</h2>`
  })
  export class ContactUsComponent { }