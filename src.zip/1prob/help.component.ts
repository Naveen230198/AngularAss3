import { Component } from '@angular/core';

@Component({
    selector: 'app-help123', //you can use any selector of your choice
    template: `<h2>HELP</h2>`
  })
  export class HelpComponent { }